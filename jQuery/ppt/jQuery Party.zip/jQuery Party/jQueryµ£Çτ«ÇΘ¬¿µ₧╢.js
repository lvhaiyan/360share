(function( window, undefined ) {
    //jQuery Core
    var jQuery = function( selector, context ) {};
    jQuery.fn = jQuery.prototype = {};
    jQuery.extend = jQuery.fn.extend = function(){};
    //jQuery 扩展方法一
    jQuery.extend({
        xxx: function() {}
    });
    //jQuery 扩展方法二
    jQuery.fn.extend({
        xxx: function() {}
    });
    //jQuery 扩展方法三
    jQuery.xxx=function(){};
    //jQuery 扩展方法四
    jQuery.fn.xxx=function{};
    // jQuery与全局的连接点，将jQuery和$挂载到window上，外放为全局变量
    // 这两个对象指向jQuery框架内部变量——jQuery
    // 这里是jQuery整体架构中重要的一环，框架内部代码和外部链接的门户
    window.jQuery = window.$ = jQuery;
})( window );