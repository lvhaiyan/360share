/*
 * 第一个有趣的延伸知识点：自执行匿名函数Immediately-Invoked Function Expression (IIFE)
 *
 * @知识索引：
 * 自执行函数：http://benalman.com/news/2010/11/immediately-invoked-function-expression/
 * 自执行函数的几种写法：http://www.jb51.net/article/31078.htm
 * 匿名函数与闭包：http://www.cnblogs.com/rainman/archive/2009/05/04/1448899.html
 *
 * @本处使用的作用：
 * 一、创建一个jQuery命名空间，保护jQuery不会和外部冲突
 * 二、为什么这里传入window，其实这里的window是一个局部变量，而不是全局变量window，提高访问性能，且方便压缩
 * 三、为什么传入undefined(属性值上下22对应，下面第二个没有值，即为undefined，那么上面的undefined即使为临时变量，也被重写为真实的undefined)，确保框架内部，undefined是真的使用未定义的undefined，而不是在框架前面被赋值的undefined变量（部分浏览器能重写undefined值）
 */
(function( window, undefined ) {
    //jQuery Core
    var jQuery = function( selector, context ) {};
    window.jQuery = window.$ = jQuery;
})( window );