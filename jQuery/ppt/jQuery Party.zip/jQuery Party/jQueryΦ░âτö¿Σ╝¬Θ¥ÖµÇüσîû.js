(function( window, undefined ) {
    var jQuery = function( selector, context ) {
            //注点1中调用时，自动构造jQuery对象，而这个jQuery对象，是jQuery.fn.init的一个实例化
            //故jQuery实例对象，前面都是没有new的，就是在这里框架内部自动完成了实例化
            return new jQuery.fn.init();
        };
    jQuery.fn = jQuery.prototype = {
        constructor: jQuery,
        init: function( ) {},
        xxx:function(){console.log('test');},
        yyy:function(){console.log('test2');}
    };
    // 将jQuery对象的fn(即prototype)赋给实例化用的init函数的prototype，使得最后返回的jQuery对象的值拥有init中的this以及fn中的值
    // 这里是框架中非常重要的一环
    // 此处进行了原型链接续，原本，jQuery实例对象，因为它是jQuery.fn.init的实例化，故只能拥有init中的this以及自己的原型链（没有接续前是空）
    // 这里这个操作，把jQuery的原型链（fn是原型链别名）接给了jQuery.fn.init，故最后的jQuery实例对象，拥有了init中的this以及自己的原型链（这时候接上了jQuery的原型链）
    // 注意，后续被扩展在jQuery原型链上的，也会被jQuery实例对象拥有（如jQuery.extend等）
    jQuery.fn.init.prototype = jQuery.fn;
    window.jQuery = window.$ = jQuery;

})( window );