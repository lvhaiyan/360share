(function( window, undefined ) {
    //jQuery Core
    var jQuery = function( selector, context ) {};
    jQuery.fn = jQuery.prototype = {};
    jQuery.extend = jQuery.fn.extend = function(){};
    //回调对象 Callback（line 919~1101)
    jQuery.Callbacks = function( options ) {};
    //延迟对象 Deferred（line 1102~1242)
    jQuery.extend({Deferred: function( func ) {}});
    //浏览器特性检测 Support（line 1243~1508)
    jQuery.support = (function() {})();
    //数据缓存 Data（line 1509~1847)
    jQuery.extend({data: function( elem, name, data, pvt /* Internal Use Only */ ) {});
    jQuery.fn.extend({data: function( key, value ) {}});
    //队列 queue（line 1848~1993)
    jQuery.extend({queue: function( elem, type, data ) {}});
    jQuery.fn.extend({queue: function( type, data ) {}});
    //属性操作 Attribute（line 1994~2625)
    jQuery.fn.extend({attr: function( name, value ) {}});
    jQuery.extend({attr: function( elem, name, value, pass ) {}});
    //事件处理 Event（line 2626~3662)
    jQuery.event = {};
    jQuery.Event = function( src, props ) {};
    jQuery.Event.prototype = {preventDefault: function() {}};
    jQuery.fn.extend({bind: function( types, selector, data, fn, /*INTERNAL*/ one ) {}});
    //选择器 Sizzle（line 3663~5353)独立框架
    //DOM遍历 Traversing（line 5354~5648)
    jQuery.fn.extend({find: function( selector ) {});
    //DOM操纵 Manipulation（line 5649~6474)
    jQuery.fn.extend({append: function() {}});
    //即将废弃 Deprecated（line 6475~6537)闭包
    //CSS操作 （line 6538~7177)
    jQuery.fn.extend({css: function( name, value ) {}});
    jQuery.extend({css: function( elem, name, numeric, extra ) {});
    //Form表单 form（line 7178~7278）
    jQuery.fn.extend({serialize: function() {}});
    jQuery.param = function( a, traditional ) {};
    //异步请求 Ajax（line 7279~8553)
    jQuery.fn.load = function( url, params, callback ) {};
    jQuery.extend({ajax: function( url, options ) {}});
    //动画 effects（line 8554~9227)
    jQuery.Animation = jQuery.extend( Animation, {});
    jQuery.Tween = Tween;
    jQuery.fn.extend({animate: function( prop, speed, easing, callback ) {}});
    jQuery.fx = Tween.prototype.init;
    //偏移 offset（line 9229~9452)
    jQuery.fn.offset = function( options ) {};
    // Expose jQuery to the global object
    window.jQuery = window.$ = jQuery;
})( window );