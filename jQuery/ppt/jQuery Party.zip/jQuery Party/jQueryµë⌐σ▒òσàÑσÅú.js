(function( window, undefined ) {
    var jQuery = function( selector, context ) {return new jQuery.fn.init();};
    jQuery.fn = jQuery.prototype = {
        constructor: jQuery,
        init: function( ) {}
        //selector jquery length属性
        //size toArray get pushStack each ready 
        //eq first last slice map end push sort splice
    };
    jQuery.fn.init.prototype = jQuery.fn;
    //继承是面向对象中一种非常重要的概念，这里是jQuery的一个实现方案
    //jQuery.extend为jQuery本体静态方法扩展入口，jQuery.fn.extend为jQuery实例扩展入口
    //这里两种不能的继承基于同一个方法，但是却为后续框架两种扩展留下入口
    jQuery.extend = jQuery.fn.extend = function() {
        var target = arguments[0] || {};
        // 返回修改后的对象
        return target;
    };
    //这里是扩展在jQuery本体的一些util静态方法
    jQuery.extend({
        // noConflict
        // isReady readyWait ready holdReady
        // type isFunction isArray isWindow isNumeric isPlainObject isEmptyObject error noop 
        // parseHTML parseJSON parseXML
        // globalEval camelCase nodeName trim
        // each makeArray inArray merge grep map
        // guid proxy access now
    });
    window.jQuery = window.$ = jQuery;

})( window );