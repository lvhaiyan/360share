(function( window, undefined ) {
    var jQuery = function( selector, context ) {return new jQuery.fn.init(selector, context, rootjQuery);};
    jQuery.fn = jQuery.prototype = {
        constructor: jQuery,
        init: function( selector, context, rootjQuery ) {
            var match, elem, ret, doc;
            // 根据selector不同，返回不同的值
            // selector有以下7种分支情况：
            // 1、""、null、undefined、false
            // 2、DOM元素
            // 3、body（优化寻找）1.7中还有，1.8没有，归到了4中，故这里源码没有
            // 4、字符串：HTML标签、HTML字符串、#id、选择器表达式
            // 5、函数（作为ready回调函数）
            // 6、jQuery对象（因为有selector值）
            // 7、其它
            this.context=xxx;
            this.length=1;
            return this;
        }
    };
    jQuery.fn.init.prototype = jQuery.fn;
    jQuery.extend = jQuery.fn.extend = function() {
        var target = arguments[0] || {};
        return target;
    };
    jQuery.extend({});
    window.jQuery = window.$ = jQuery;

})( window );