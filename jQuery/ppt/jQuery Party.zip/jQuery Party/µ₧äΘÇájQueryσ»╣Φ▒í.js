(function( window, undefined ) {
    var jQuery = function( selector, context ) {
        };
    /*
     * jQuery.fn相当于jQuery.prototype的别名，指向的是同一份内容
     * 第二个有趣的延伸知识点：js原型prototype
     *
     * @知识索引：
     * 原型和继承：http://www.cnblogs.com/ljchow/archive/2010/06/08/1753526.html
     * prototype和constructor：http://blog.csdn.net/niuyongjie/article/details/4810835
     *
     * @本处使用的作用
     * 主要是为了一些core方法的扩展准备（此处只做init核心方法的注释，其它方法请查看api结合源码了解）。
     * 注：按照prototype的概念，只有new jQuery的自身实例化能使用这里的方法，而jQuery对象，不是自身实例化，而是jQuery.fn.init的实例化，用不了这里的方法。
     *     有上面的问题，故有后面的原型链接续，使jQuery对象能使用这里的方法
     */
    jQuery.fn = jQuery.prototype = {
        //构造器，便于内部使用this.constructor这种看起来超类继承的写法，更符合OOP思维
        constructor: jQuery,
        init: function( selector, context, rootjQuery ) {},
        xxx:function(){
            console.log('test');
        }
    };
    window.jQuery = window.$ = jQuery;

})( window );